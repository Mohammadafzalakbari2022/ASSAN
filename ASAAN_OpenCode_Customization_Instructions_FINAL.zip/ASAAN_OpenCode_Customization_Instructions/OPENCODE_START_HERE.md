# OpenCode — Master Execution Command

You are customizing the existing ecommerce repository into **ASAAN**.

This is a controlled implementation task. Follow the supplied instruction files exactly and work from the actual repository. Do not invent architecture or add features that are not requested.

## Phase 0 — Read first

Read ALL of these files before making implementation changes:

- `README.md`
- `01_AUDIT_AND_BASELINE.md`
- `02_SINGLE_SHOP.md`
- `03_LANGUAGES_CURRENCIES_COUNTRY.md`
- `04_DATE_SYSTEM.md`
- `05_USER_FACING_BRANDING_AND_REFERENCES.md`
- `06_ADMIN_UI_PLUGINS_AND_SETTINGS.md`
- `07_TESTING_SECURITY_AND_REGRESSION.md`
- `08_FINAL_ACCEPTANCE.md`

## Phase 1 — Audit before editing

Inspect the complete repository.

Create `ASAAN_CUSTOMIZATION_AUDIT.md`.

Do not begin destructive changes until the architecture is understood.

## Phase 2 — Implement in order

Implement each numbered requirement in sequence.

After each logical phase:
1. inspect the diff;
2. run relevant tests/builds;
3. verify that no unrelated files/features changed;
4. create a small Git commit if the repository is under Git.

## Phase 3 — Date requirement is mandatory

The date system is NOT optional.

ASAAN must support BOTH:
- Gregorian date
- Afghan Solar Hijri date

Important distinction:

**Afghan Solar Hijri is not Iranian/Persian Solar Hijri.**

If month names are ever displayed, use Afghan month names such as:
- Hamal
- Sawr
- Jawza
- Saratan
- Asad
- Sonbola
- Mizan
- Aqrab
- Qaws
- Jadi
- Dalwa
- Hoot

However, the preferred product UI is to avoid month names where practical and display numeric Afghan dates.

Do NOT substitute Iranian month names such as Farvardin, Ordibehesht, Khordad, Tir, Mordad, Shahrivar, Mehr, Aban, Azar, Dey, Bahman, Esfand.

The full implementation requirements are in `04_DATE_SYSTEM.md`. Follow that file literally.

## Phase 4 — Final verification

Repeat the repository search and functional tests.

Create `ASAAN_CUSTOMIZATION_FINAL_REPORT.md`.

Do not claim completion if a mandatory requirement is unverified.
