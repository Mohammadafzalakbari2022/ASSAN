# 02 — Enforce ASAAN Single-Shop Mode

## Requirement

ASAAN is sold as one shop. The customer must not be presented with a multi-shop/multi-site administration product.

## Hide

Hide user-facing/admin controls for:

- Create shop
- Add shop
- Create site
- Add site
- Site selector
- Site switcher
- Site management
- Multi-shop management
- Multi-site management
- Additional shop/domain management
- Tenant management
- Unneeded multi-vendor shop creation

## Block direct access

Hiding a menu is NOT sufficient.

Where the actual implementation allows it, protect creation/management routes/actions with proper backend authorization, middleware or application-level restrictions.

If a hidden action is requested directly, return an appropriate forbidden/authorization response or safe redirect.

## Preserve architecture

Do NOT delete:

- Aimeos site tables
- site relationships
- required site IDs
- multi-site framework classes
- required catalog/order relationships

The desired architecture is:

Internal engine:
`multi-site capable`

ASAAN application:
`one exposed/authorized shop`

## Implementation priority

Prefer:

1. configuration
2. application configuration
3. route restrictions
4. authorization/middleware
5. view/menu overrides
6. application extensions/service providers
7. vendor changes only if unavoidable

If vendor code must be modified, document exactly why.

## Verification

Test:
- storefront
- admin
- products
- categories
- orders
- checkout
- no shop selector
- no create-shop action
- no site-switch action
- direct creation/management attempt is blocked
