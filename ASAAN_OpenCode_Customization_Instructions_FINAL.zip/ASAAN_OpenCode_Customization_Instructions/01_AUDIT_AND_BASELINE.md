# 01 — Full Repository Audit and Baseline

## Goal

Understand the actual project before modifying it.

## Inspect the whole repository

Inspect, as applicable:

- root files
- README/documentation
- `composer.json` / lock file
- Laravel configuration
- routes
- controllers
- middleware
- policies/authorization
- service providers
- models
- database migrations
- seeders
- Aimeos configuration
- Aimeos extensions
- views/Blade templates
- frontend JavaScript/CSS
- translations
- mail templates
- invoice/PDF generation
- PWA/manifest assets
- public assets
- tests
- deployment configuration
- environment examples

Do not assume paths. Locate the actual implementation.

## Establish baseline

Run the project's documented test/build commands.

Record current status for:

- storefront
- admin login
- dashboard
- products
- categories
- customers
- inventory
- cart/basket
- checkout
- order creation
- language selector
- currency selector
- existing date displays

Record pre-existing failures separately.

## Repository-wide search

Search for:

- `Aimeos`
- `aimeos`
- `aimeos.org`
- site/shop
- multi-site
- multi-shop
- multi-vendor
- tenant
- channel
- localization
- locale
- language
- currency
- country
- plugin
- extension
- domain
- date
- calendar
- Jalali
- Solar Hijri
- Persian calendar
- Iranian calendar
- Gregorian

Also inspect external URLs.

## Classification

For each important finding classify:

A. Internal framework/package reference — KEEP
B. Required legal/license/copyright/attribution — KEEP
C. User-facing platform branding — REPLACE/HIDE
D. Unwanted ASAAN feature — HIDE/BLOCK
E. Potentially removable implementation — INVESTIGATE
F. Unknown — DO NOT GUESS

## Required audit document

Create `ASAAN_CUSTOMIZATION_AUDIT.md` with:

1. architecture summary
2. shop/site architecture
3. admin navigation
4. routes for unwanted management
5. current locales
6. current currencies
7. current countries
8. current date handling
9. date libraries/packages
10. date storage/database behavior
11. all user-facing Aimeos references
12. external links
13. emails/invoices
14. metadata/PWA
15. plugins/extensions
16. files that should remain untouched
17. license/attribution requirements
18. baseline tests
19. implementation plan
20. risks/unknowns

Do not skip the date-system audit.
