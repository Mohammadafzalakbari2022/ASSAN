# 03 — Languages, Currencies and Country

## Languages — exactly three

Customer-facing language choices:

1. **Dari / دری** — DEFAULT
2. **Pashto / پښتو** — SECOND
3. **English** — THIRD

Keep the storefront language selector.

No fourth language may appear.

## Critical locale rule

The visible label "Dari" must not be treated as permission to invent a technically invalid locale.

Inspect how the current Aimeos/Laravel installation loads Persian/Afghanistan translations. Use the technically correct locale supported by the installed translation system, while presenting the language to users as **Dari / دری**.

Do not replace working locale identifiers merely for cosmetic reasons.

## Hide generic language management

Hide unnecessary admin controls for:

- adding languages
- removing languages
- editing supported locales
- localization management
- generic locale management

## Currency — exactly two

1. **AFN — Afghan Afghani** — DEFAULT
2. **USD — US Dollar** — SECONDARY

No other customer-facing currencies.

Hide generic currency-management controls.

## Country

ASAAN is Afghanistan-focused.

Use Afghanistan as the relevant country configuration.

Hide generic country-management controls where they are not needed.

Do not delete underlying country/currency/locale architecture if required by the commerce engine.

## Verification

Confirm:
- Dari default
- Pashto works
- English works
- selector contains only three
- AFN default
- USD selectable
- no other currencies visible
- no unnecessary locale/currency/country management visible
