# 08 — Final Acceptance

Do not declare the customization complete until the following checklist is verified.

## Identity
- ASAAN spelling is correct.
- Unnecessary Aimeos branding is removed from normal user-facing surfaces.
- Required third-party legal notices remain.

## Single shop
- One shop/site exposed.
- Additional shop creation hidden and blocked.
- Site switching hidden.
- Additional domain/site management hidden.
- Underlying database architecture remains intact.

## Languages
- Dari default.
- Pashto second.
- English third.
- Selector remains.
- No other languages exposed.

## Currency
- AFN default.
- USD secondary.
- No other currencies exposed.

## Country
- Afghanistan is the relevant visible/configured country.
- Generic country management hidden.

## Date systems — mandatory
- Gregorian supported.
- Afghan Solar Hijri supported.
- Dashboard can show both.
- Customer-facing calendar is configurable by admin.
- Customer default is Afghan date.
- Customer can be switched to Gregorian by admin.
- No Iranian/Persian calendar is offered.
- No Iranian month names appear.
- If month names exist, they are Afghan names.
- Numeric Afghan dates are correct.
- Timezone/time-of-day behavior remains correct.
- Database date storage/sorting is not broken.

## Admin
- Unnecessary site/localization/currency/country/plugin controls hidden.
- Essential ecommerce features still work.
- Hidden capabilities are protected against direct access.

## Branding/references
- User-facing messages use ASAAN or neutral wording.
- Unnecessary Aimeos/vendor links removed.
- Metadata/PWA/email/invoice surfaces audited.
- Required legal attribution preserved.

## Final search

Repeat the repository-wide search.

For every remaining user-facing:
- `Aimeos`
- `aimeos.org`
- Iranian/Persian date terminology

explain why it remains.

## Final report

Create `ASAAN_CUSTOMIZATION_FINAL_REPORT.md` containing:
1. summary
2. audit findings
3. files changed
4. files intentionally unchanged
5. single-shop implementation
6. languages/currencies/country
7. date-system implementation
8. admin changes
9. branding/reference changes
10. plugin/module changes
11. protected routes/actions
12. tests performed
13. baseline failures
14. remaining issues
15. license/attribution considerations
16. future logo/icon integration points
17. rollback instructions

End with:

`ASAAN ready for logo/icon integration: YES/NO`

If NO, list exactly what remains.
