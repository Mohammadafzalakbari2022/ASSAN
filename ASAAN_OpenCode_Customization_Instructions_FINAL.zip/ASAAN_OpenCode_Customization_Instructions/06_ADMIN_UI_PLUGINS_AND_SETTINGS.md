# 06 — Admin UI, Plugins and Settings

## Admin principle

Show only functionality relevant to ASAAN's single-shop ecommerce operation.

## Keep essential features

Preserve features actually required by the project, such as:
- Dashboard
- Products
- Categories
- Orders
- Customers
- Inventory
- Payments
- Shipping
- Reports
- essential settings
- authentication

Do not remove existing business functionality merely because it was not listed.

## Hide unnecessary generic management

Investigate and hide:
- Sites/Shops
- site switching
- localization
- locales
- language management
- currency management
- country management
- additional domain management
- multi-vendor
- tenants
- channels
- generic plugin/extension management
- unnecessary developer tools
- irrelevant platform configuration

## Plugin rule

Do NOT uninstall everything called "plugin".

Some plugins/extensions are core to ecommerce.

Create an audit table:

| Module/plugin | Purpose | Required? | Customer/admin visible? | Action | Reason |
|---|---|---|---|---|---|

Keep required modules.

Only hide/remove genuinely unnecessary user-facing integrations.

## Navigation

Audit:
- sidebar
- top navigation
- dropdowns
- breadcrumbs
- settings tabs
- action menus
- dashboard widgets

## Direct routes

For hidden management capabilities, test direct URLs and backend actions.

## Date setting

Ensure the appropriate admin setting for customer-facing date mode is discoverable and usable.

The admin must be able to choose:
- Afghan date
- Gregorian

Do not expose Iranian/Persian date options.

## Logo placeholder

Do not generate logo/icon files now. A supplied ASAAN asset pack will be integrated in a later phase.
