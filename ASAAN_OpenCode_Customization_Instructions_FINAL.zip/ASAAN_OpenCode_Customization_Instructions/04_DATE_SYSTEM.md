# 04 — Mandatory ASAAN Date System

## This requirement is critical

ASAAN must support **two date systems**:

1. **Gregorian**
2. **Afghan Solar Hijri**

The Afghan Solar Hijri calendar must be treated as the Afghanistan calendar, NOT as the Iranian/Persian Solar Hijri calendar.

## Terminology

Use the term:

**Afghan date / Afghan Solar Hijri**

Do not label it as:
- Iranian date
- Iranian calendar
- Persian calendar
- Persian date

If the UI needs a short label, prefer:
- `Afghan`
- `Afghan date`
- `Gregorian`

## Very important distinction

Afghanistan and Iran use different month names for the Solar Hijri calendar.

If month names are displayed, ASAAN MUST use Afghan month names:

1. Hamal
2. Sawr
3. Jawza
4. Saratan
5. Asad
6. Sonbola
7. Mizan
8. Aqrab
9. Qaws
10. Jadi
11. Dalwa
12. Hoot

Do NOT use Iranian month names such as:

- Farvardin
- Ordibehesht
- Khordad
- Tir
- Mordad
- Shahrivar
- Mehr
- Aban
- Azar
- Dey
- Bahman
- Esfand

## Preferred display

To eliminate unnecessary cultural ambiguity, the preferred UI is to use numeric dates rather than month names wherever practical.

Example:

`1405/06/21`

rather than:

`21 Sonbola 1405`

If a month name is required by an existing component, use the Afghan month name.

## Storage rule

Do not change database date storage merely to display Afghan dates.

The system should normally store actual timestamps/dates in a reliable canonical format, typically Gregorian/UTC according to the application's existing architecture.

Convert dates at the presentation/application layer.

Do not store a formatted Afghan date string in place of an actual timestamp if that would break sorting, querying, reporting, payment, order or database logic.

## Dashboard/admin requirement

The dashboard must support both:

- Gregorian date
- Afghan Solar Hijri date

The administrator must have a clear setting controlling which date system customers see.

The setting should conceptually be:

`Customer date format/calendar`

with choices:

- `Afghan date`
- `Gregorian`

Default customer-facing setting:

**Afghan date**

Do not expose Iranian/Persian calendar as an option.

## Customer-facing requirement

Customer-facing dates should be configurable by the admin.

When the admin selects **Afghan date**, customer-facing dates must use Afghan Solar Hijri.

When the admin selects **Gregorian**, customer-facing dates must use Gregorian.

Do not show Iranian/Persian Solar Hijri dates.

Examples:

Order date:
- Afghan mode: `1405/06/21`
- Gregorian mode: `2026/09/12`

The exact converted date must be calculated by a reliable calendar implementation, not guessed or hard-coded.

## Dashboard display

The dashboard/admin should be able to show both date systems where useful.

Preferred format:

`2026/09/12 | 1405/06/21`

Avoid month names unless needed.

This dual display is especially useful for:
- order dates
- reports
- dashboard summaries
- invoices where appropriate
- audit logs
- appointments/schedules if the project contains them

## Date/time requirements

Do not accidentally remove time-of-day.

If the application has date + time values, preserve the time component.

Example:

`2026/09/12 14:30 | 1405/06/21 14:30`

Use the application's correct timezone handling.

Do not change timezone behavior as part of this customization unless the repository shows a date bug directly related to this requirement.

## Calendar implementation

First inspect whether the existing project already has a reliable Solar Hijri/Jalali implementation.

If one exists:
- determine whether it is genuinely compatible with Afghan month naming and Afghan display requirements;
- do not assume that a package named "Jalali" automatically means the visible month names are correct for Afghanistan.

If a library is needed, choose an actively maintained, technically appropriate implementation and keep the change minimal.

Do not add a large date framework when a small existing dependency or existing application capability is sufficient.

## Date formatting configuration

Centralize customer-facing date formatting.

Do not scatter hard-coded date conversions throughout Blade templates/controllers.

Create or reuse the project's appropriate date/formatting abstraction so that:

`customer_date_mode = afghan`

or

`customer_date_mode = gregorian`

controls all relevant customer-facing dates consistently.

## Areas to audit

Search the whole repository for date formatting and update relevant customer-facing locations:

- homepage
- product pages
- customer account
- orders
- order history
- checkout
- invoices
- emails
- shipping information
- admin dashboard
- reports
- audit logs
- notifications
- API responses used by the frontend
- JSON serialization where displayed to users

Do not change machine-readable API dates unless necessary. If an API is consumed by JavaScript, preserve stable machine-readable values and convert only at the presentation layer.

## Admin control

The setting must be accessible to the appropriate administrator.

Do not create a new role system just for this.

Use the existing settings/authorization structure.

The customer should never be able to change the global customer-facing calendar setting unless the existing product explicitly allows that kind of configuration.

## Translation

If labels are translated:
- use `Afghan date` / `د افغانستان نېټه` / the project's correct Dari/Pashto wording as appropriate;
- do not label the Afghan calendar as Iranian/Persian.

Do not hard-code untranslated English labels into every template if the application already has a translation system.

## Tests

At minimum test:

1. Dashboard shows Gregorian date.
2. Dashboard can show Afghan date.
3. Customer date mode defaults to Afghan.
4. Customer sees Afghan date when setting is Afghan.
5. Customer sees Gregorian date when setting is Gregorian.
6. No Iranian month names appear.
7. Numeric Afghan dates are correct.
8. If month names are used anywhere, they are Afghan names.
9. Order sorting/querying still works.
10. Checkout/order timestamps still work.
11. Emails/invoices use the configured customer-facing mode where appropriate.
12. Timezones remain correct.
13. Machine-readable API dates are not unnecessarily corrupted.
14. Direct access to the date setting respects existing admin authorization.

## Acceptance examples

Correct:
`1405/06/21`

Correct:
`2026/09/12`

Correct if month names are required:
`21 Sonbola 1405`

Incorrect:
`21 Shahrivar 1405`

Incorrect:
`21 Farvardin 1405`

Incorrect:
`Persian calendar`

Incorrect:
`Iranian calendar`

## Final date audit

Before completion, search the repository for:
- Persian calendar
- Iranian calendar
- Farvardin
- Ordibehesht
- Khordad
- Tir
- Mordad
- Shahrivar
- Mehr
- Aban
- Azar
- Dey
- Bahman
- Esfand

Any remaining occurrence must be explained in the final report. Internal library documentation may be legitimate; user-facing Iranian terminology is not acceptable.
