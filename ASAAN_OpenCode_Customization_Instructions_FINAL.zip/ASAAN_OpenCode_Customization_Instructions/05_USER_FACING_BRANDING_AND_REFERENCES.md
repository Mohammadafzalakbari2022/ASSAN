# 05 — User-Facing ASAAN Branding and References

## Goal

The customer-facing and normal admin experience should feel like a coherent ASAAN product.

## Inspect every surface

- storefront
- admin
- login
- password reset
- account pages
- menus
- breadcrumbs
- buttons
- dialogs
- confirmations
- toast notifications
- validation
- success/error messages
- empty states
- browser titles
- HTML metadata
- OpenGraph metadata
- manifest/PWA
- emails
- invoices/PDFs
- 404/403/419/422/429/500 pages
- API messages shown directly to users
- footer/about/help/contact
- external links

## Aimeos references

Replace unnecessary user-facing Aimeos branding with ASAAN or neutral wording.

Example:
`Aimeos shop created` -> `Shop created successfully.`

Do not globally replace all Aimeos occurrences.

Keep:
- internal namespaces
- Composer package names
- framework internals
- required license text
- required copyright
- legally required attribution

## External links

Audit all user-facing external URLs, especially:
- Aimeos website
- Aimeos documentation
- Aimeos GitHub
- unnecessary vendor/partner links
- irrelevant plugin links

Remove or replace unnecessary links.

Do not remove legally required links/notices.

## Metadata

Make normal metadata ASAAN-oriented:
- title
- application name
- description
- OpenGraph
- PWA name/short name
- icons when later supplied

## Emails/invoices

Remove unnecessary platform branding and prepare for ASAAN branding.

Do not break transactional content.

## Error pages

Do not expose unnecessary framework/package names to customers.

Keep detailed diagnostics in logs.
