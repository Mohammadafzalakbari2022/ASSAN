# 07 — Testing, Security and Regression

## Run actual project tests

Use the repository's documented test/build commands.

## Public storefront

Verify:
- homepage
- categories
- products
- search
- cart
- checkout
- order creation
- customer account
- language switching
- currency switching
- customer-facing dates

## Admin

Verify:
- login
- dashboard
- products/categories
- orders
- customers
- inventory
- reports
- relevant settings
- date/calendar setting

## Single shop

Verify:
- one shop exposed
- no selector
- no create-shop UI
- direct creation blocked
- unwanted site management blocked

## Language

Verify only:
- Dari
- Pashto
- English

## Currency

Verify only:
- AFN
- USD

## Date

Test both modes:

### Afghan
Customer sees Afghan Solar Hijri dates.

### Gregorian
Customer sees Gregorian dates.

Verify:
- no Iranian month names
- no Persian/Iranian calendar label
- Afghan numeric date conversion is correct
- dashboard can show both systems
- time remains correct
- database sorting remains correct
- reports remain correct
- email/invoice behavior is correct

## Security

Hidden features must not become available merely by manually entering their URLs or submitting obvious requests.

Use actual authorization/middleware/backend checks.

## Browser console

Check application errors:
- JS exceptions
- missing assets
- 404 JS/CSS
- failed API calls
- failed localization calls

Separate browser-extension errors from application errors.

## Regression

Compare results to the baseline.

Report:
- fixed baseline issues
- unchanged baseline issues
- new regressions

Do not hide failures.

## Git

Use small commits. Never force-push or destroy existing work.
