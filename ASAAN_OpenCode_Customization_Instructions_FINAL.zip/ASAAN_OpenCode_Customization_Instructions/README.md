# ASAAN — OpenCode Customization Master Instructions

## Purpose

These instructions define the controlled customization of the existing Aimeos/Laravel project into **ASAAN**, a polished **single-shop ecommerce application**.

OpenCode MUST follow these instructions in order. Do not improvise new product requirements, redesign architecture unnecessarily, or add unrelated features.

The repository itself is the source of truth for filenames, routes, configuration keys, services, extensions and implementation details. Inspect it before changing anything.

## Non-negotiable product rules

- Product name: **ASAAN** exactly — spelled A-S-A-A-N (Asaan).
- Do not use Asaan, ASAAN, Asaan, or another spelling in new user-facing text.
- Single shop only.
- Preserve the underlying Aimeos architecture where it is useful internally.
- Do not blindly replace every occurrence of Aimeos.
- Do not unnecessarily edit `vendor/`.
- Preserve legally required third-party license/copyright/attribution.
- Exactly 3 customer-facing languages: Dari, Pashto, English.
- Exactly 2 customer-facing currencies: AFN and USD.
- Country context: Afghanistan only.
- Dates are a major product requirement; follow `08_DATE_SYSTEM.md` exactly.
- Do not generate or invent the logo/icon pack in this phase.
- Do not add unrelated features.

## Required execution order

1. `01_AUDIT_AND_BASELINE.md`
2. `02_SINGLE_SHOP.md`
3. `03_LANGUAGES_CURRENCIES_COUNTRY.md`
4. `04_DATE_SYSTEM.md`
5. `05_USER_FACING_BRANDING_AND_REFERENCES.md`
6. `06_ADMIN_UI_PLUGINS_AND_SETTINGS.md`
7. `07_TESTING_SECURITY_AND_REGRESSION.md`
8. `08_FINAL_ACCEPTANCE.md`

Create `ASAAN_CUSTOMIZATION_AUDIT.md` before implementation and `ASAAN_CUSTOMIZATION_FINAL_REPORT.md` at completion.
